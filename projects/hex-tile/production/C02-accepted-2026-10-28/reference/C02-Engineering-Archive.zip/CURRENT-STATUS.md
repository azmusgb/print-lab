# Current C02 selection

C02 geometry is retained unchanged. The original geometry and render evidence
inside hex-tile-c02 remains a historical exact-revision record.

The newly attached preflight was independently inspected. Current findings,
process rationale and readiness are in _c02-preflight/QUALIFICATION-REVIEW.md.
The selected four-file delivery is in c02-selected-delivery/.

Both selected 3MFs are UNSLICED editable qualification projects. Their package
structure and geometry were checked; native Bambu import, reslicing, updated
ETA and physical acceptance remain outstanding. They contain no old G-code.

The input 3MF under upload/ and the two Python scripts preserve reproducibility
of this inspection. The scripts require the dependencies in
hex-tile-c02/requirements.txt. The top-level checksum manifest covers this
complete archive, excluding itself; the earlier nested manifest covers its
original geometry-evidence subtree.
