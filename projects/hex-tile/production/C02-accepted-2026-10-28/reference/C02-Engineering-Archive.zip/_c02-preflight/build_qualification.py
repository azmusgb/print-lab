"""Derive an UNSLICED C02 project; preserve original preflight and geometry."""
from pathlib import Path
import zipfile,json,hashlib,xml.etree.ElementTree as ET,shutil,posixpath,copy,uuid
import numpy as np

ROOT=Path(__file__).resolve().parent
BASE=ROOT.parent
INPUT=BASE/'upload/C02_tile-single_PREFLIGHT_stockPLAMatte220.gcode.3mf'
DEST=BASE/'c02-selected-delivery'
DEST.mkdir(exist_ok=True)
CORE='http://schemas.microsoft.com/3dmanufacturing/core/2015/02'
PROD='http://schemas.microsoft.com/3dmanufacturing/production/2015/06'
BAMBU='http://schemas.bambulab.com/package/2021'
RELS='http://schemas.openxmlformats.org/package/2006/relationships'

def sha(data):return hashlib.sha256(data).hexdigest()
def xml_bytes(root,default=None):
    if default:ET.register_namespace('',default)
    ET.register_namespace('p',PROD);ET.register_namespace('BambuStudio',BAMBU)
    return ET.tostring(root,encoding='utf-8',xml_declaration=True)

def main():
    assert sha(INPUT.read_bytes())=='b783587668a2aa116356328630039c762a7b030f82deca1e85b6453b0a54384e'
    with zipfile.ZipFile(INPUT) as z:parts={n:z.read(n) for n in z.namelist()}
    original_settings=json.loads(parts['Metadata/project_settings.config'])
    cfg=json.loads(parts['Metadata/project_settings.config'])
    changes={}
    def set_value(key,value):
        assert key in cfg,key
        changes[key]={'from':cfg[key],'to':value};cfg[key]=value
    def set_array(key,value):set_value(key,[str(value)]*len(cfg[key]))
    set_value('print_settings_id','C02 Qualification 0.20mm - Dense Shell')
    set_value('sparse_infill_density','100%')
    set_value('sparse_infill_pattern','rectilinear')
    set_value('brim_object_gap','0')
    for key,value in {
        'outer_wall_speed':40,'inner_wall_speed':150,
        'internal_solid_infill_speed':100,'sparse_infill_speed':100,
        'gap_infill_speed':100,'top_surface_speed':50,
        'vertical_shell_speed':80,'travel_speed':500,
        'default_acceleration':2000,'outer_wall_acceleration':500,
        'inner_wall_acceleration':1500,'travel_acceleration':3000,
        'top_surface_acceleration':1000,
    }.items():set_array(key,value)
    # Keep the diagnostic enabled. Full fill is not a reason to suppress warnings.
    assert cfg['detect_floating_vertical_shell']=='1'
    assert cfg['ensure_vertical_shell_thickness']=='enabled'
    for key in ['printer_settings_id','filament_settings_id','nozzle_diameter',
                'layer_height','initial_layer_print_height','wall_loops',
                'wall_generator','wall_sequence','enable_support',
                'brim_width','brim_type','initial_layer_speed',
                'initial_layer_acceleration','nozzle_temperature',
                'nozzle_temperature_initial_layer','filament_flow_ratio',
                'filament_max_volumetric_speed','textured_plate_temp',
                'textured_plate_temp_initial_layer','fan_min_speed','fan_max_speed',
                'additional_cooling_fan_speed','machine_start_gcode','machine_end_gcode']:
        assert cfg[key]==original_settings[key],key
    parts['Metadata/project_settings.config']=(json.dumps(cfg,indent=2)+'\n').encode()

    model=ET.fromstring(parts['3D/3dmodel.model'])
    for meta in list(model.findall(f'{{{CORE}}}metadata')):
        if meta.attrib.get('name','').startswith('Thumbnail_'):model.remove(meta)
        elif meta.attrib.get('name')=='Title':meta.text='C02 Single Tile - Qualification'
        elif meta.attrib.get('name')=='Description':
            meta.text='Derived C02 qualification setup; process edited externally. Unsliced: re-slice in Bambu Studio. No production-ready claim.'
    # ElementTree removes unused namespace declarations; retain custom metadata prefix.
    model.set('xmlns:BambuStudio',BAMBU)
    parts['3D/3dmodel.model']=xml_bytes(model,CORE)
    settings=ET.fromstring(parts['Metadata/model_settings.config'])
    for meta in settings.findall('.//metadata'):
        if meta.attrib.get('key') in ['name','source_file'] and meta.attrib.get('value')=='HEX_TILE_v73.stl':
            meta.set('value','C02_tile-single.stl')
    plate=settings.find('plate')
    for meta in list(plate.findall('metadata')):
        if meta.attrib.get('key') in ['gcode_file','thumbnail_file','thumbnail_no_light_file','top_file','pick_file']:
            plate.remove(meta)
    parts['Metadata/model_settings.config']=xml_bytes(settings)
    removed=[]
    for name in list(parts):
        if name.endswith(('.gcode','.gcode.md5','.png')) or name in [
            'Metadata/plate_1.json','Metadata/slice_info.config',
            'Metadata/_rels/model_settings.config.rels']:
            removed.append(name);del parts[name]
    relationships=ET.fromstring(parts['_rels/.rels'])
    for rel in list(relationships):
        if rel.attrib.get('Target','').lstrip('/') not in parts:relationships.remove(rel)
    parts['_rels/.rels']=xml_bytes(relationships,RELS)
    output=DEST/'C02_SINGLE_QUALIFICATION.3mf'
    with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED) as z:
        for n,data in parts.items():z.writestr(n,data)
    with zipfile.ZipFile(output) as z:
        assert z.testzip() is None
        assert not any(n.endswith(('.gcode','.gcode.md5')) for n in z.namelist())
        assert 'Metadata/slice_info.config' not in z.namelist()
        assert z.read('3D/Objects/object_1.model')==zipfile.ZipFile(INPUT).read('3D/Objects/object_1.model')
        for n in z.namelist():
            if n.endswith(('.xml','.model','.rels','.config')) and n!='Metadata/project_settings.config':ET.fromstring(z.read(n))
        native=json.loads(z.read('Metadata/project_settings.config'))
        for key,item in changes.items():assert native[key]==item['to']
        # Every retained OPC relationship resolves inside the package.
        for n in z.namelist():
            if not n.endswith('.rels'):continue
            if n=='_rels/.rels':owner=''
            else:owner=posixpath.dirname(posixpath.dirname(n))
            for rel in ET.fromstring(z.read(n)):
                target=rel.attrib['Target']
                resolved=target.lstrip('/') if target.startswith('/') else posixpath.normpath(posixpath.join(owner,target))
                assert resolved in z.namelist(),(n,resolved)
        original_model=ET.fromstring(zipfile.ZipFile(INPUT).read('3D/3dmodel.model'))
        assert model.find(f'{{{CORE}}}build/{{{CORE}}}item').attrib==original_model.find(f'{{{CORE}}}build/{{{CORE}}}item').attrib
        assert model.attrib['requiredextensions']=='p' and b'xmlns:p=' in z.read('3D/3dmodel.model')
    shutil.copyfile(BASE/'hex-tile-c02/tile.scad',DEST/'tile.scad')
    # Independent pair: preserve the reviewed orientation and share mesh resources,
    # with two separate build instances, 20 mm apart along the tile-depth axis.
    pair_parts=dict(parts)
    pair_model=ET.fromstring(parts['3D/3dmodel.model'])
    build=pair_model.find(f'{{{CORE}}}build')
    first=build.find(f'{{{CORE}}}item'); second=copy.deepcopy(first)
    values=np.array(list(map(float,first.attrib['transform'].split())))
    linear=values[:9].reshape(3,3).T
    original_transform=np.eye(4);original_transform[:3,:3]=linear;original_transform[:3,3]=values[9:]
    ns={'c':CORE}
    mesh_xml=ET.fromstring(parts['3D/Objects/object_1.model'])
    vertices=np.array([[float(v.attrib[k]) for k in ['x','y','z']] for v in mesh_xml.findall('.//c:vertex',ns)])
    world=vertices@linear.T+values[9:]
    center=(world.min(axis=0)+world.max(axis=0))/2
    offset=np.array([128.,128.,center[2]])-center
    normal=-linear[:,1]
    pitch=19.+20.
    all_vertices=[]
    for item,sign in [(first,-1),(second,1)]:
        v=values.copy();v[9:]+=offset+sign*normal*pitch/2
        item.set('transform',' '.join(format(x,'.12g') for x in v))
        all_vertices.append(vertices@linear.T+v[9:])
    second.set(f'{{{PROD}}}UUID',str(uuid.uuid4()))
    build.append(second)
    pair_model.set('xmlns:BambuStudio',BAMBU)
    for meta in pair_model.findall(f'{{{CORE}}}metadata'):
        if meta.attrib.get('name')=='Title':meta.text='C02 Independent Pair - Qualification'
    pair_parts['3D/3dmodel.model']=xml_bytes(pair_model,CORE)
    pair_settings=ET.fromstring(parts['Metadata/model_settings.config'])
    plate=pair_settings.find('plate'); instance=plate.find('model_instance')
    second_instance=copy.deepcopy(instance)
    for m in second_instance.findall('metadata'):
        if m.attrib['key']=='instance_id':m.set('value','1')
        if m.attrib['key']=='identify_id':m.set('value','16')
    plate.append(second_instance)
    pair_parts['Metadata/model_settings.config']=xml_bytes(pair_settings)
    bounds=np.array([np.vstack(all_vertices).min(axis=0),np.vstack(all_vertices).max(axis=0)])
    assert np.all(bounds[0,:2]-13>=0) and np.all(bounds[1,:2]+13<=256)
    assert bounds[1,2]+5<=256
    proj=[v@normal for v in all_vertices]
    gap=float(proj[1].min()-proj[0].max())
    assert abs(gap-20)<1e-7
    pair_output=DEST/'C02_PAIR_QUALIFICATION.3mf'
    with zipfile.ZipFile(pair_output,'w',zipfile.ZIP_DEFLATED) as z:
        for n,data in pair_parts.items():z.writestr(n,data)
    with zipfile.ZipFile(pair_output) as z:
        assert z.testzip() is None
        for n in z.namelist():
            if n.endswith(('.xml','.model','.rels','.config')) and n!='Metadata/project_settings.config':ET.fromstring(z.read(n))
        assert len(ET.fromstring(z.read('3D/3dmodel.model')).find(f'{{{CORE}}}build'))==2
        assert len(ET.fromstring(z.read('Metadata/model_settings.config')).find('plate').findall('model_instance'))==2
        assert z.read('3D/Objects/object_1.model')==parts['3D/Objects/object_1.model']
        assert not any(n.endswith(('.gcode','.gcode.md5')) for n in z.namelist())
    report={'input_sha256':sha(INPUT.read_bytes()),'output_sha256':sha(output.read_bytes()),
      'builder_sha256':sha(Path(__file__).read_bytes()),
      'output_name':output.name,'geometry_xml_unchanged':True,'build_transform_unchanged':True,
      'stale_slice_cache_removed':removed,'settings_changes':changes,
      'zip_crc_check':'PASS','xml_json_parse':'PASS','package_relationships':'PASS',
      'native_bambu_import_test':'NOT PERFORMED - Bambu Studio not installed in this runtime',
      'reslice':'REQUIRED; modified settings have no validated ETA or toolpaths',
      'physical_test':'NOT PERFORMED','production_ready':False,
      'pair':{'output_name':pair_output.name,'sha256':sha(pair_output.read_bytes()),
              'independent_build_instances':2,'raw_depth_axis_gap_mm':gap,
              'world_bounds_mm':bounds.tolist(),'xy_allowance_each_side_mm':13,
              'usable_volume_mm':[256,256,256],'bounds_with_allowances':'PASS'}}
    (ROOT/'qualification-project-check.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))

if __name__=='__main__':main()
