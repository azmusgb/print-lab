from pathlib import Path
import re,json,math,zipfile,xml.etree.ElementTree as ET,importlib.util,hashlib
import numpy as np
import trimesh
from collections import defaultdict

ROOT=Path(__file__).resolve().parent
INPUT=ROOT.parent/'upload/C02_tile-single_PREFLIGHT_stockPLAMatte220.gcode.3mf'

def read_paths():
    lines=zipfile.ZipFile(INPUT).read('Metadata/plate_1.gcode').decode().splitlines()
    state={'X':0.,'Y':0.,'Z':0.,'E':0.,'F':0.}
    role='Custom';height=None;width=.42;layer_h=.2;acc=0.;relative_e=True
    result=[]
    for linenum,raw in enumerate(lines,1):
        if raw.startswith('; Z_HEIGHT:'):height=float(raw.split(':',1)[1])
        if raw.startswith('; FEATURE:'):role=raw.split(':',1)[1].strip()
        if raw.startswith('; LINE_WIDTH:'):width=float(raw.split(':',1)[1])
        if raw.startswith('; LAYER_HEIGHT:'):layer_h=float(raw.split(':',1)[1])
        line=raw.split(';',1)[0].strip()
        if not line:continue
        cmd=line.split()[0]
        fields={k:float(v) for k,v in re.findall(r'([XYZEFIJSP])\s*([-+]?\d*\.?\d+)',line[len(cmd):])}
        if cmd=='M83':relative_e=True
        if cmd=='M82':relative_e=False
        if cmd=='M204' and 'S' in fields:acc=fields['S']
        if cmd=='G92':state.update({k:v for k,v in fields.items() if k in state});continue
        if cmd not in ['G0','G1','G2','G3']:continue
        start=np.array([state[k] for k in 'XYZ'])
        end=np.array([fields.get(k,state[k]) for k in 'XYZ'])
        de=fields.get('E',0) if relative_e else fields.get('E',state['E'])-state['E']
        if 'F' in fields:state['F']=fields['F']
        points=np.vstack([start,end]);length=float(np.linalg.norm(end[:2]-start[:2]))
        if cmd in ['G2','G3'] and ('I' in fields or 'J' in fields):
            center=start[:2]+[fields.get('I',0),fields.get('J',0)]
            radius=np.linalg.norm(start[:2]-center)
            a0=math.atan2(start[1]-center[1],start[0]-center[0]);a1=math.atan2(end[1]-center[1],end[0]-center[0])
            sweep=(a1-a0)%(2*math.pi) if cmd=='G3' else -((a0-a1)%(2*math.pi))
            if abs(sweep)<1e-9:sweep=2*math.pi*(1 if cmd=='G3' else -1)
            length=float(abs(sweep)*radius)
            angle=np.linspace(a0,a0+sweep,max(2,int(math.ceil(length/.3))+1))
            points=np.c_[center[0]+radius*np.cos(angle),center[1]+radius*np.sin(angle),np.linspace(start[2],end[2],len(angle))]
        state.update({k:fields[k] for k in 'XYZ' if k in fields})
        state['E']=state['E']+de if relative_e else fields.get('E',state['E'])
        if de>0 and length>1e-5 and height is not None and role!='Custom':
            result.append({'line':linenum,'height':height,'role':role,'width':width,
                           'layer_h':layer_h,'feed_mm_s':state['F']/60,'acc_mm_s2':acc,
                           'e_mm':de,'length_mm':length,'points':points})
    return result

def load_meshes():
    with zipfile.ZipFile(INPUT) as z:
        ns={'c':'http://schemas.microsoft.com/3dmanufacturing/core/2015/02'}
        root=ET.fromstring(z.read('3D/Objects/object_1.model'))
        verts=np.array([[float(v.attrib[k]) for k in ['x','y','z']] for v in root.findall('.//c:vertex',ns)])
        faces=np.array([[int(t.attrib[k]) for k in ['v1','v2','v3']] for t in root.findall('.//c:triangle',ns)])
        obj=trimesh.Trimesh(verts,faces,process=False)
        root=ET.fromstring(z.read('3D/3dmodel.model'))
        vals=np.array(list(map(float,root.find('.//c:item',ns).attrib['transform'].split())))
        M=np.eye(4);M[:3,:3]=vals[:9].reshape(3,3).T;M[:3,3]=vals[9:]
    spec=importlib.util.spec_from_file_location('c02validator',ROOT.parent/'hex-tile-c02/validate.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    xyz,tris,_=module.expected_face_pattern()
    xy=np.stack([obj.triangles[:,:,0],obj.triangles[:,:,2]],axis=-1).reshape(-1,2)
    values=np.full(len(xy),np.nan)
    for t in tris:
        bary=np.linalg.solve(np.vstack([xyz[t,:2].T,np.ones(3)]),np.vstack([xy.T,np.ones(len(xy))])).T
        inside=np.all(bary>=-2e-5,axis=1);values[inside]=bary[inside]@xyz[t,2]
    values=values.reshape(-1,3)
    mask=np.all(np.abs((9.5-obj.triangles[:,:,1])-values)<.002,axis=1)&(obj.face_normals[:,1]<-.1)
    front=obj.submesh([np.flatnonzero(mask)],append=True)
    front.apply_transform(M)
    return obj,M,front

def main():
    input_sha=hashlib.sha256(INPUT.read_bytes()).hexdigest()
    assert input_sha=='b783587668a2aa116356328630039c762a7b030f82deca1e85b6453b0a54384e'
    with zipfile.ZipFile(INPUT) as z:
        code=z.read('Metadata/plate_1.gcode')
        assert hashlib.md5(code).hexdigest().upper()==z.read('Metadata/plate_1.gcode.md5').decode().strip().upper()
    paths=read_paths();obj,M,front=load_meshes();inverse=np.linalg.inv(M)
    expected=trimesh.load_mesh(ROOT.parent/'hex-tile-c02/artifacts/tile-trial_single.stl')
    aligned=obj.copy();aligned.apply_translation(expected.bounds.mean(axis=0)-obj.bounds.mean(axis=0))
    distances=[]
    for a,b in [(aligned,expected),(expected,aligned)]:
        distances.extend(trimesh.proximity.closest_point(b,np.vstack([a.vertices,a.triangles_center]))[1])
    assert max(distances)<.002 and obj.is_watertight and len(obj.split())==1
    byrole=defaultdict(list)
    for p in paths:byrole[p['role']].append(p)
    summary={}
    for role,parts in byrole.items():
        summary[role]={'height_range_mm':[min(p['height'] for p in parts),max(p['height'] for p in parts)],
          'extruding_segments':len(parts),'path_length_mm':sum(p['length_mm'] for p in parts),
          'extruded_filament_mm':sum(p['e_mm'] for p in parts),
          'maximum_commanded_speed_mm_s':max(p['feed_mm_s'] for p in parts),
          'maximum_commanded_acceleration_mm_s2':max(p['acc_mm_s2'] for p in parts),
          'maximum_segment_length_mm':max(p['length_mm'] for p in parts)}
    floating=[p for p in paths if p['role']=='Floating vertical shell']
    sample=[];heights=[]
    for p in floating:
        pts=p['points'];n=max(2,int(math.ceil(p['length_mm']/.5))+1)
        if len(pts)==2:pts=np.linspace(pts[0],pts[-1],n)
        pts=pts.copy();pts[:,2]-=p['layer_h']/2
        sample.extend(pts);heights.extend([p['height']]*len(pts))
    sample=np.array(sample);heights=np.array(heights)
    _,distance,_=trimesh.proximity.closest_point(front,sample)
    distance_report={}
    for name,mask in [('all',np.ones(len(heights),bool)),('upper',heights>=120),('bottom',heights<10)]:
        distance_report[name]={'samples':int(mask.sum()),'minimum_centerline_to_display_mm':float(distance[mask].min()),
             'maximum_centerline_to_display_mm':float(distance[mask].max()),'sample_step_target_mm':.5}
    bridge=[]
    for h in sorted({p['height'] for p in paths if p['role']=='Bridge'}):
        parts=[p for p in paths if p['role']=='Bridge' and p['height']==h]
        bridge.append({'height_mm':h,'max_toolpath_segment_length_mm':max(p['length_mm'] for p in parts),
            'segment_count':len(parts),'layer_height_annotations_mm':sorted({p['layer_h'] for p in parts})})
    role_caps={'Outer wall':40,'Inner wall':150,'Floating vertical shell':80,'Sparse infill':100,'Internal solid infill':100,'Gap infill':100,'Top surface':50}
    original=sum(p['length_mm']/max(p['feed_mm_s'],.01) for p in paths)
    capped=sum(p['length_mm']/max(min(p['feed_mm_s'],role_caps.get(p['role'],p['feed_mm_s'])),.01) for p in paths)
    from shapely.geometry import LineString
    from shapely.ops import unary_union
    layer=[p for p in paths if abs(p['height']-.2)<1e-5]
    def bead_shape(parts):
        return unary_union([LineString(p['points'][:,:2]).buffer(p['width']/2,quad_segs=4) for p in parts])
    brim=bead_shape([p for p in layer if p['role']=='Brim'])
    footprint=bead_shape([p for p in layer if p['role']!='Brim'])
    first_layer={'first_layer_model_regions':len(footprint.geoms) if footprint.geom_type=='MultiPolygon' else 1,
        'first_layer_model_ideal_bead_area_mm2':footprint.area,'brim_to_model_ideal_bead_gap_mm':brim.distance(footprint),
        'scope':'Nominal centerline buffers; excludes actual bead spread/first-layer squish. Not an adhesion prediction.'}
    assert first_layer['first_layer_model_regions']==1
    (ROOT/'first-layer-check.json').write_text(json.dumps(first_layer,indent=2)+'\n')
    filament_header=float(re.search(rb'total filament length \[mm\]\s*:\s*([\d.]+)',code).group(1))
    filament_parsed=sum(p['e_mm'] for p in paths)
    assert abs(filament_parsed-filament_header)<.05
    report={'input_sha256':input_sha,
      'parser_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
      'gcode_md5_match':True,'filament_mm_from_header':filament_header,'filament_mm_from_paths':filament_parsed,
      'mesh_identity':{'watertight':bool(obj.is_watertight),'components':len(obj.split()),
                       'dimensions_mm':obj.extents.tolist(),'volume_mm3':float(obj.volume),
                       'maximum_bidirectional_sample_surface_deviation_mm':float(max(distances))},
      'first_layer':first_layer,
      'path_roles':summary,'floating_shell_distance':distance_report,'bridge_roles':bridge,
      'extrusion_feed_time_seconds_original':original,'extrusion_feed_time_seconds_quality_caps_same_paths':capped,
      'feed_time_scope':'Nominal positive-extrusion path length/feed only. Excludes acceleration, travel, macro time, and changed infill paths; not a slicer ETA.'}
    (ROOT/'path-analysis.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))
    plot(paths,obj,M,inverse)

def plot(paths,obj,M,inverse):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib.collections import LineCollection
    colors={'Outer wall':'#203b4b','Inner wall':'#55859b','Floating vertical shell':'#c43b31','Sparse infill':'#d1a443','Gap infill':'#aaa8a0','Internal solid infill':'#7c699d','Bridge':'#da762f','Top surface':'#567b43'}
    fig,axs=plt.subplots(3,2,figsize=(14,10),facecolor='#f6f5f2')
    for ax,h in zip(axs.flat,[120.,124.,126.,128.,130.,131.2]):
        for role,color in colors.items():
            segments=[]
            for p in paths:
                if abs(p['height']-h)>.001 or p['role']!=role:continue
                q=trimesh.transform_points(p['points'],inverse)
                segments.extend(np.stack([np.c_[q[:-1,0],9.5-q[:-1,1]],np.c_[q[1:,0],9.5-q[1:,1]]],axis=1))
            if segments:ax.add_collection(LineCollection(segments,colors=color,linewidths=.65,label=role))
        ax.set(xlim=(-47,47),ylim=(-.6,14),xlabel='Tile width coordinate (mm)',ylabel='Depth from rear plane (mm)',title=f'Print height {h:g} mm')
        ax.grid(alpha=.15);ax.set_aspect('equal',adjustable='box')
    handles={}
    for ax in axs.flat:
        for h,l in zip(*ax.get_legend_handles_labels()):handles[l]=h
    fig.legend(handles.values(),handles.keys(),loc='lower center',ncol=4,frameon=False)
    fig.suptitle('C02: actual upper-region extrusion paths\nRed = slicer-classified floating vertical shell; display side is upward in each section',fontsize=15)
    fig.tight_layout(rect=[0,.08,1,.94])
    fig.savefig(ROOT/'upper-toolpaths.png',dpi=150);plt.close(fig)

if __name__=='__main__':main()
