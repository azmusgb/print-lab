# Independent C02 preflight review and selected setup

## Identity

Both supplied 3MF files have SHA-256 `b783587668a2aa116356328630039c762a7b030f82deca1e85b6453b0a54384e` and are byte-identical. The embedded G-code MD5 matches its stored checksum. This review used one copy; no difference is inferred from the filenames.

The embedded part retains a stale `HEX_TILE_v73.stl` name. Direct mesh inspection found 69 vertices, 134 triangles, one watertight solid, 57,024.329 mm³ volume, and 152.399994 × 19 × 131.981995 mm dimensions. Bidirectional nearest-surface probes at all vertices and triangle centers, after aligning centers, differ from the packaged C02 single mesh by at most 0.00000331 mm. The old label therefore does not identify a different tile in this file. Derived projects relabel it C02.

## Directly verified original process

Bambu Studio 02.08.02.61, X2D 0.4/0.4 mm, process `Hex Tile v70 - Recent 0.20mm @BBL X2D 0.4 nozzle`, 0.20 mm layers, three Classic walls, inner/outer order, 15% grid, five top/three bottom solid layers, vertical-shell detection enabled, supports off, 8 mm outer brim and 0.1 mm brim gap. Stock PLA Matte: 220 °C, active flow 1.006, 22 mm³/s cap, density 1.32 g/cm³, Textured PEI 55 °C, part fan 100%, auxiliary fan setting 70%.

Embedded prediction: 7,147 s total (1 h 59 min 7 s), 22,840.30 mm filament, 72.52 g, 660 layers. Positive model/brim extrusion in the independent parser reconciles to 22,840.29431 mm, within the header's rounding. The G-code header's volume comment labels 54,937.35 as cm³; filament length and diameter reconcile that value to mm³, or 54.93735 cm³. The reported 72.52 g uses the embedded density, not an assumed generic PLA density.

## Actual upper paths

Display contours continue through the upper region. The red paths in `upper-toolpaths.png` are slicer-classified internal roof-shell paths; the label does not mean the display skin is an unsupported island. Floating-shell labels occur at the lower closure around Z=1.4 mm and again near Z=124–131 mm.

Sampled floating-path bead-center-to-display distances range from about 1.35 to 7.92 mm in the upper zone, with the closest points near the perimeter returns. These distances are toolpath locations, not a CAD air-gap or wall-thickness measurement. They do not certify the 1.6 mm isolation requirement and do not establish freedom from telegraphing.

Bridge-role extrusion appears at Z=1.6 and 131.2 mm. Their maximum single toolpath segment lengths are approximately 9.88 and 9.74 mm. These are segment lengths, not measured unsupported span lengths. The following layers include internal solid fill; no claim that all internal closure paths are bridge-free is made.

The center of the upper closure grows from approximately 2.4 mm local material depth at Z=120 mm to 4.84 mm at Z=124 and 8.13 mm at Z=128. That is a real geometric mass transition. A visual mark remains possible even if support is adequate.

## Motion omitted from the CLI summary

Actual positive-extrusion commands reach:

| Role | Commanded speed | Commanded acceleration |
|---|---:|---:|
| Outer wall | 80 mm/s | 1,500 mm/s² |
| Inner wall | 250 mm/s | 6,000 mm/s² |
| Floating vertical shell | 200 mm/s | 6,000 mm/s² |
| Internal solid infill | 250 mm/s | 6,000 mm/s² |

These are commanded values, not measured nozzle speeds or tile motion. They identify a credible motion-quality concern in a tall print; they do not prove an observed failure. Slowdown decisions use the product's face-quality priority and permitted time budget rather than a diagnosis that the original motion is physically incapable of working.

## First-layer brim qualification

Nominal bead buffers reconstructed from the actual first-layer paths give one connected model region, approximately 651.98 mm² model bead area, and approximately 0.270 mm minimum separation between the brim and model regions. This excludes real bead spreading and first-layer squish. The 0.1 mm configured brim gap and 0.2 mm elephant-foot compensation must not be treated as a proven fused base. The selected setup changes requested brim gap to zero while retaining compensation. Reslicing must establish the resulting path gap, and a physical print must establish actual attachment and clean removal. No claim that this alone solves adhesion or upright motion is made.

## Invalid T messages resolved

The file's only literal T commands are T65279 and T65535 in its end-of-print filament-return macro, after model printing. They are also present in the embedded machine end template. Bambu Studio's own checker source explicitly exempts both values in its T-command validation branch. This supports a parser-compatibility explanation for the two log messages; no tile-layer tool change or geometry defect is established by them. Firmware execution was not tested here.

Primary source: https://github.com/bambulab/BambuStudio/blob/master/bbs_test_tools/bbs_gcode_checker/GCodeChecker.cpp

For role interpretation, Bambu's configuration definitions describe floating-shell detection and vertical-shell speed relative to solid-infill speed. The original 80% of 250 mm/s corresponds to the observed 200 mm/s maximum.

Primary source: https://github.com/bambulab/BambuStudio/blob/master/src/libslic3r/PrintConfig.cpp

## Selected engineering decision

Freeze C02 geometry. Use fully filled modeled shell regions with moderate motion, preserving the supplied 0.20 mm/three-wall/stock-material basis. Exact changes are in `qualification-project-check.json` and the short delivery guide. The open rear cavity is modeled empty space and is not filled by 100% infill.

Expected benefits: eliminate sparse grid as the internal roof-shell foundation and reduce excitation/pressure transients. Costs: additional plastic/heat and longer printing. Residual risks: geometric roof mass still increases, thermal bands may persist, and dynamic/adhesive/cleanup behavior is untested. This is one selected qualification configuration. A future success would support the whole configuration, not establish which individual process change caused it.

The native projects are deliberately UNSLICED: all G-code, MD5, slice estimates, cached toolpath images and links to those caches are removed. They preserve the exact original geometry and reviewed orientation. The pair uses two separate build instances with approximately 20 mm projected raw clearance; 8 mm brim plus 5 mm machine margins per side fit the specified bed. Full native Bambu Studio import/reslicing was not possible in this runtime.

Independent feed-time integration on the unchanged ORIGINAL paths gives roughly 79.7 min positive-extrusion feed time, or 146.9 min with the selected role speed caps. This excludes travel, acceleration and all changes to infill toolpaths, so it is NOT an ETA for either revised project. A fresh Studio estimate is required; no under-nine-hour claim is made for the revised pair.

## Current readiness

| Classification | Scope and status |
|---|---|
| GEOMETRICALLY VALIDATED | C02: yes, within the earlier documented CAD checks. Geometry unchanged. |
| SLICER VALIDATED | Original supplied preflight: directly inspected. Selected revised setup: not resliced or native-import-tested here. |
| PHYSICALLY TESTED | No C02 physical result supplied. |
| REPEATABILITY VALIDATED | No. |
| PRODUCTION READY | No. Selected geometry and process are ready for the stated qualification steps, subject to successful native import/reslice. |

Original evidence and prior reports are retained as historical records. This review supersedes their statement that no C02 slicer artifact had been inspected; it does not retroactively update the exact source/render test results or invent physical evidence.
