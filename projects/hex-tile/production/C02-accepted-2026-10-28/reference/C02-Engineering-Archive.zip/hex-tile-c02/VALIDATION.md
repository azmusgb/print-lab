# C02 validation report

**GEOMETRICALLY VALIDATED within stated checks. Unprinted engineering candidate; NOT PRODUCTION READY.**

## Revision and appearance

C02 replaces the symmetric central fan with five offset interior junctions and 13 distinct facet planes. Fourteen explicit triangle patches form the surface; two intentionally share the broad right-hand plane. XY positions approximately follow the supplied reference. Z depths are selected design values and are not recovered facts from the image.

Source SHA-256: `db63e63359e278f510fc355f08c0f76c3ff487bbb605de3a5df4bb1adbc63cda`

Validator SHA-256: `d8ac2954ab9f698f82b604bafc7407b143099ebd05b277a0d1b71ff1be1963b9`

Reference image SHA-256: `8622e20e400834870739d2eedacb57a5285b6fc04e5cee8fce2f16ff56895817`

Tools: openscad OpenSCAD version 2021.01, python 3.12.14, numpy 2.3.5, trimesh 5.2.0, shapely 2.2.0, networkx 3.7, rtree 1.4.1, matplotlib 3.10.8.

## OpenSCAD and mesh checks

All four output modes parsed and rendered with `--hardwarnings`; CGAL reported `Simple: yes`. Default assertions passed. Meshes were independently inspected with trimesh.

| Output | Connected components | Watertight | Winding consistent | XYZ dimensions (mm) | CAD volume (mm³) |
|---|---:|---|---|---|---:|
| inspect | 1 | True | True | 152.4000 × 131.9822 × 19.0000 | 57025.544 |
| trial_single | 1 | True | True | 152.4000 × 19.0000 × 131.9820 | 57024.342 |
| trial_pair | 2 | True | True | 152.4000 × 58.0000 × 131.9820 | 114048.683 |
| section | 1 | True | True | 76.2000 × 131.9822 × 19.0000 | 28510.290 |

All components have positive volume. Zero duplicate triangles and zero degenerate triangles below 1e-8 mm² were found. The pair intentionally contains two independent one-solid tiles. CGAL Volumes includes the exterior and is not the finished-part count. No separate exhaustive self-intersection solver or entire parameter-space proof was run.

## Face, shell and mounting

| Check | Result | Evidence |
|---|---|---|
| Distinct display planes | 13 | Actual mesh normal groups; 14 intended triangle patches |
| Interior junctions | 5 | Fixed normalized XY and controlled height fractions |
| Triangle XY coverage | Exact full-hex coverage within 1e-6 mm² | Shapely union/difference and overlap reconciliation |
| Display area | 15295.68663 mm² mesh vs 15295.69491 mm² analytic | Actual triangles reconciled to specified height field |
| Maximum facet gradient | 0.22613993 | Per-triangle gradient solve |
| Conservative minimum skin separation | 2.340891 mm | 2.4 mm axial skin / sqrt(1+maximum_gradient²) |
| Rear-land to face-skin clear-air bound | ≥4.096558 mm | Conservative analytic bound; exceeds 1.6 mm |
| Sampled land-to-inner-face distance | 4.552708 mm minimum | 125 actual-mesh nearest-point probes; supplements the analytic bound |
| Rear-plane deviation | 0.000000 mm | Actual coplanar rear triangles; CAD only |
| Total rear coplanar area | 5748.559 mm² | Includes narrow shell returns, not all designated for tape |
| Tape placement | Five 12.7 mm strips; 3×50 mm plus 2×30 mm | 2,667 mm² nonoverlapping nominal tape area |
| Transverse placement tolerance | −2.5, 0, +2.5 mm shifts passed | All strips checked against mesh rear-plane coverage with 0.002 mm tolerance |

The isolation bound applies to the rear tape land and face skin. Integral perimeter/roof shell joins necessarily connect the skin; no air gap or thermal isolation is asserted at those joins. The specification interpretation limitation and telegraphing risk remain documented in ENGINEERING.md. No printed flatness or bond strength result is inferred.

## Full-height section checks and bed fit

660 sections at 0.2 mm spacing remained one connected region. Maximum new area outside the preceding section buffered by 0.202 mm was 0.000000 mm². This is geometric sampling with 0.002 mm tolerance, not a slicer path, extrusion support, vibration or thermal simulation.

The ideal lower-edge contact is 76.2×9=685.8 mm². The Z=0.1 mm sampled section measured 688.074 mm², one connected region. Upright STL minimum Z is approximately 0.000000171 mm from numerical serialization; mathematical placement is at Z=0. Confirm actual connected first-layer contact in the slicer.

| Layout | Raw XYZ (mm) | Reserved envelope XYZ (mm) | Assumed usable volume (mm) |
|---|---|---|---|
| Single | 152.4 × 19 × 131.982 | 178.4 × 45 × 136.982 | 256 × 256 × 256 |
| Pair | 152.4 × 58 × 131.982 | 178.4 × 84 × 136.982 | 256 × 256 × 256 |

Reservations include 8 mm brim and 5 mm extra margin on each XY side, plus 5 mm headroom. Raw pair gap is 20 mm and nominal brim gap 4 mm. Brims are slicer geometry, not in CAD. Machine-specific exclusions, purge lines and toolhead envelopes require slicer review. Sequential printing is not qualified.

Pair components matched the single geometrically after bounding-box alignment at all vertex and triangle-center probes within 0.002 mm. This does not establish equal printed quality.

## Assertions and variations

26 invalid-parameter cases produced explicit assertion failures; no stale STL was accepted. Cases:

- `unknown_mode`: `{"mode":"production"}`
- `wrong_nominal_size`: `{"corner_diameter":160}`
- `negative_depth`: `{"edge_depth":-1}`
- `excessive_depth`: `{"facet_rise":20}`
- `thin_skin`: `{"skin_axial":1}`
- `thin_perimeter`: `{"perimeter_wall":1}`
- `thin_land`: `{"land_thickness":1}`
- `no_land_overlap`: `{"perimeter_wall":18}`
- `face_isolation`: `{"edge_depth":6}`
- `cannot_lower_isolation_limit`: `{"minimum_face_isolation":0.5}`
- `narrow_tape_land`: `{"land_width":15}`
- `no_tape_tolerance`: `{"tape_edge_allowance":1}`
- `closed_cavity`: `{"land_width":60}`
- `zero_roof_slope`: `{"roof_slope":0}`
- `steep_roof`: `{"roof_slope":2}`
- `overlapping_brims`: `{"pair_gap":10}`
- `negative_brim`: `{"planned_brim":-1}`
- `negative_margin`: `{"machine_margin":-1}`
- `bed_x`: `{"build_x":170}`
- `bed_y_pair`: `{"mode":"trial_pair","build_y":80}`
- `bed_z`: `{"build_z":130}`
- `unsupported_line_width`: `{"nominal_line_width":1}`
- `short_face_profile`: `{"facet_profile":[0.8,0.55,1]}`
- `zero_face_profile`: `{"facet_profile":[0,0.55,1,0.6]}`
- `unnormalized_face_profile`: `{"facet_profile":[0.8,0.55,0.9,0.6]}`
- `negative_face_profile`: `{"facet_profile":[-0.8,0.55,1,0.6]}`

Four one-variable diagnostic variants rendered as one watertight, consistently wound positive-volume solid: edge depth 10 mm, facet rise 8 mm, land width 19 mm, and nominal line width 0.4 mm. Detailed face/mounting/section probes apply to the default C02 values. These variants are not physically qualified.

## Readiness

| Classification | Status |
|---|---|
| GEOMETRICALLY VALIDATED | PASS, stated CAD checks only |
| SLICER VALIDATED | NOT PERFORMED |
| PHYSICALLY TESTED | NOT PERFORMED |
| REPEATABILITY VALIDATED | NOT PERFORMED |
| PRODUCTION READY | NO |

Outstanding: selected printer/material/profile and native slicer project; full-size single/pair prints; face/perimeter acceptance; high-level motion; cooled dimensions and rear flatness; timed brim cleanup; handling; exact adhesive/wall durability; actual print duration; repeated print runs; applicable project/material acceptance. No physical success or repeatability result has been invented. See ENGINEERING.md for the risk review, parameter table, process records, change control and acceptance plan.
