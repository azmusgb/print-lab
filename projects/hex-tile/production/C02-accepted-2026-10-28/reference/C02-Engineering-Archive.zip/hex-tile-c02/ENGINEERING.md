# C02 — Faceted architectural hex wall tile

**Unreleased engineering candidate. Geometry checks passed within the scope below. This is not a perfected, physically qualified commercial product.**

The source implements a complete candidate selected from the outcome-based brief. A face reference image was supplied for C02. No original 3D CAD, exact depth map, printer, material, slicer profile, adhesive product, wall substrate, service environment, or physical print was supplied. These are not inferred from other projects. Consequently, an optimal manufacturing architecture and production readiness cannot be established from this package alone.

## Package and use

| File | Purpose |
|---|---|
| `tile.scad` | Complete standalone parametric OpenSCAD source; default is `trial_single`. |
| `artifacts/tile-trial_single.stl` | One upright tile, centered in the assumed 256 mm square usable bed; trial only. |
| `artifacts/tile-trial_pair.stl` | Two independent upright tiles, same orientation; trial only. |
| `artifacts/tile-inspect.stl` | Finished single tile in wall coordinates; not the primary print orientation. |
| `artifacts/tile-section.stl` | Half-tile cutaway for inspection, not a production part. |
| `artifacts/variation-*.stl` | Explicit parameter-change diagnostic outputs, not qualified alternatives. |
| `design-preview.png` | Angled front/rear views of the actual mesh; not a photograph of printed finish. |
| `face-preview.png` | Head-on view of the actual revised CAD face. |
| `reference-face.png` | User-provided appearance reference; exact heights cannot be recovered from it. |
| `validate.py` | Rebuilds outputs, exercises assertions, inspects geometry, and regenerates the preview. |
| `evidence/validation.json` | Machine-readable numeric results, source identity, tool versions and limitations. |
| `evidence/*.log` | OpenSCAD render and expected rejection logs. |
| `VALIDATION.md` | Human-readable results for the exact packaged revision. |
| `PRINT_RECORD_TEMPLATE.json` | Blank physical-run record; nulls mean evidence has not been collected. |
| `SHA256SUMS.txt` | Integrity manifest for the package contents, excluding itself. |

Open `tile.scad` and render with F6. Select only a mode with the purpose you need. To rebuild:

```bash
python3 -m pip install -r requirements.txt
python3 validate.py
```

The validation script requires an installed `openscad` executable. It deletes stale target meshes before each render and removes `validation.json` on failure. Preserve the original package before rerunning, because rebuilding replaces its evidence files. STL serialization can vary by tool version; compare dimensions/topology as well as hashes when changing tools.

To export directly:

```bash
openscad --hardwarnings --export-format asciistl -o single.stl tile.scad
openscad --hardwarnings --export-format asciistl -D 'mode="trial_pair"' -o pair.stl tile.scad
```

## Design rationale

**The visible face is an asymmetric piecewise-planar relief inspired by the supplied image.** It has five offset interior junctions, 14 explicit triangle patches and 13 distinct visible facet planes. Two patches intentionally share a plane to preserve the reference's broad right-hand facet. The 152.4 mm corner diameter gives 131.982 mm across flats and 76.2 mm side lengths. The rear plane is local Z=0, the perimeter face is Z=9 mm, and the highest offset junction is Z=19 mm. The junction locations approximately follow the image in XY. Their Z heights are selected engineering values, not measured or recovered from a single shaded image. The pattern is deterministic and identical between tiles; it is not random triangulation.

**The face skin uses a translated inner copy of the same height field.** A 2.4 mm axial offset gives a calculated conservative minimum normal separation of 2.341 mm across the pattern, based on its maximum facet gradient. Thickness normal to individual facet planes varies with slope. This global height-field bound also covers cross-facet nearest-distance possibilities at creases. This is explicitly distinguished from normal thickness in both naming and validation. An in-plane 2.4 mm perimeter return connects the skin to the rear. There are no interior ribs, bosses, central mounting pads, pair ties, or floating components.

**The tape interface is an integral 17.7 mm wide, 2.4 mm thick U-shaped rear land.** It covers the lower horizontal edge and the four inclined sides, stopping 17.7 mm below the upper edge. Width is measured perpendicular to the hex edges. This accommodates 12.7 mm tape with a nominal 2.5 mm transverse placement allowance on each side. The top rear perimeter strip is only a shell return; it is not a designated tape land. Five checked strip placements use three 50 mm pieces and two 30 mm pieces, totaling 2,667 mm² nominal adhesive area. This area is geometric and is not a load rating. Actual load transfer, wall coating adhesion, creep, temperature resistance, and bond preparation remain untested.

**Printing upright keeps the display face away from the bed and supports.** The lower horizontal edge provides a full 76.2 × 9 mm nominal bed-contact rectangle, approximately 685.8 mm² before adding a brim. It is not a point or isolated island. A 45-degree internal roof advances from the already printed face toward the rear as height increases. The upper tape crossbar is omitted to avoid a long rear bridge. The roof plane's sign is intentional: reversing it would introduce rear islands.

**The base is still narrow relative to the print height.** A shell with a rear land is expected to resist bending better than an isolated thin face, but this is an engineering inference, not a stiffness or vibration result. No load simulation, modal analysis, extrusion simulation, or thermal simulation was performed. Brim allowance and conservative initial motion settings are candidates for testing, not demonstrated cures for upper-height movement.

**Two tiles share a job without sharing plastic.** There are no pair ties, breakaway braces, connecting flanges, or separation operations. The pair has a raw minimum 20 mm gap and nominal 4 mm clearance between two 8 mm brim allowances. This avoids tie-removal damage by construction. It does not establish that two tiles print with equivalent cooling, vibration, seam quality, or cycle time. Qualify the single first, then evaluate the pair independently.

**Commercial appearance is the release goal, not a result demonstrated here.** The geometry preserves exact facets and contains no support contacts on the display face. It cannot guarantee invisible layer texture, ringing, density-transition banding, perimeter damage, or heat distortion. The rear land and upper roof introduce material-distribution transitions that may still telegraph. Printed samples must decide whether this architecture is acceptable.

This candidate was selected for simplicity, a hollow connected structure, practical tape placement and elimination of pair-separation hardware. Comparative physical evidence is required before describing it as optimal.

### Installation layout basis

Keep the open end of the rear U-land upward. The preview's five tape rectangles show nominal placement, not a bonded-load qualification. The installed face projects 9…19 mm from the rear land, plus the actual compressed tape thickness. That thickness and wall flatness determine the installed offset and must be controlled between tiles.

No installation joint width was supplied. For a chosen perpendicular edge gap `g`, the flat-top hex center grid has basis vectors `(0, 2a+g)` and `((2a+g)cos(30°), (2a+g)/2)`, with `a=65.991136 mm` at nominal size. These derived spacings preserve equal gaps; 152.4 mm is not the across-flats pitch. Use a project-specific positioning template or spacers and a dry panel trial before tape bonding. No alignment jig is included or claimed to be validated. Installed seam consistency and wall offset are physical acceptance checks.

## Isolation definition and proof scope

The controlled rear feature is the tape land occupying local Z=0…2.4 mm. The nominal face skin occupies the asymmetric piecewise-planar surfaces and their translated underside. The minimum underside height anywhere on the full face is 9−2.4=6.6 mm. Thus a global Z-separation of at least 4.2 mm exists between the land and that underside wherever a cavity is present. The source uses the more conservative value

```text
facet gradients = solve dz = gx*dx + gy*dy for each explicit triangle
maximum gradient = max(sqrt(gx²+gy²)) = 0.22613993
normal factor = sqrt(1 + maximum_gradient²)
minimum skin normal = skin_axial / normal factor
conservative land-to-face-skin air bound
    = (edge_depth − skin_axial − land_thickness) / normal factor
    = 4.09656 mm at the defaults, exceeding 1.6 mm
```

This is an analytic bound, supplemented by nearest-point checks against the exported inner-face mesh and strip coverage checks against the actual rear-plane triangles. It is not based only on a CAD screenshot. The sampled mesh distance is supplementary; the finite sample alone is not a global proof.

**Boundary of the claim:** the perimeter return and sloped upper roof are intrinsic parts of the connected shell. They necessarily join the face skin. No air-gap claim is made at these shell joints, nor is thermal isolation proved there. The requirement's word “effective” does not define a distance metric or exempt shell joints explicitly. This package therefore reports the rear-land clearance and facet thickness separately rather than claiming that every interpretation of the brief's isolation requirement has been certified. If every structural shell return must also maintain an air gap, this architecture does not meet that interpretation. Thermal telegraphing at all joins remains a physical acceptance gate.

## C02 change record

Purpose: replace C01's symmetric central fan with the supplied asymmetric visual direction. The controlled design change is the face height field and its matching translated inner surface. The U-land, perimeter width, roof strategy, nominal dimensions, print orientation, layouts and manufacturing allowances retain their C01 values. Their geometric interaction with the revised face is rechecked rather than assumed.

Expected measurable effects: 13 distinct facet planes and five interior junctions; 152.4 × 131.982 × 19 mm bounds retained; minimum skin ≥2 mm; rear-land isolation bound ≥1.6 mm; one watertight solid per tile; connected sampled sections with ≤1:1 advance. These geometric criteria passed. Actual printed appearance and vibration are untested. CAD volume changed from 56,882.612 mm³ in C01 to 57,025.544 mm³ in C02, approximately +0.25%; no cycle-time or material-consumption result is inferred from that alone.

The fixed normalized junction XY coordinates (in corner-radius units) are A=(-0.36,0.18), B=(0.02,0.46), C=(0.16,0.05), D=(-0.16,-0.38), E=(0.34,-0.28). Default rises above the 9 mm edge plane are A=8, B=5.5, C=10, D=6 and E=5.735534 mm. E is derived from the plane through C and the right/lower-right boundary corners. This deliberately keeps the broad right-hand surface coplanar. The fixed triangulation is explicit in the source; the validator reconciles its XY union to the full hex and checks for overlap.

The C01 baseline source SHA-256 was `f9fbdb8ab3a69bf12ea2a30579853c1d94c3136724aba7872b31708fc11c8d53`. C02 source and reference image hashes are in the current validation evidence. All physical qualification gates remain open.

## Parameter table

Ranges below describe geometry admitted by the assertions, not a physically qualified operating window. All linear values are mm. Derived limits must hold together; changing any parameter invalidates the physical qualification of an existing process until evaluated.

| Parameter | Default | Units | Purpose | Valid range / condition | Dependencies |
|---|---:|---|---|---|---|
| `mode` | `trial_single` | enum | Output purpose | `trial_single`, `trial_pair`, `inspect`, `section` only | Pair count and fit checks |
| `corner_diameter` | 152.4 | mm | 6-inch corner diameter | 150.876…153.924 at default tolerance | Apothem, cavity, facet slopes, bed fit |
| `edge_depth` | 9 | mm | Face height at outline | >0; total depth ≤25; isolation and roof guards must pass | Skin, land, roof, facet rise |
| `facet_rise` | 10 | mm | Maximum junction rise over perimeter | >0; total depth ≤25; maximum triangle gradient ≤advance limit | Size, profile, skin-normal thickness |
| `facet_profile` | [0.80, 0.55, 1.00, 0.60] | fraction | Relative rises at A, B, C, D; E derived | Exactly four positive fractions, maximum exactly 1; E in (0,1]; all thickness/slope guards pass | Facet rise, fixed junction XY, skin, clearance |
| `skin_axial` | 2.4 | mm | Inner-face Z offset | >0; normal thickness ≥minimum; air bound ≥minimum | Facet gradient, edge depth, land thickness |
| `perimeter_wall` | 2.4 | mm | In-plane cavity inset | ≥4 line widths; ≥half skin normal; <land width; roof fit | Cavity, line width, roof |
| `roof_slope` | 1 | mm/mm | Rearward advance per upright height | >0 and ≤advance limit; roof transition must fit | Edge depth, perimeter, land, apothem |
| `land_width` | 17.7 | mm | Tape band width normal to edges | ≥tape+2 allowances; >wall; opening circumradius ≥minimum | Tape dimensions, apothem, cavity |
| `land_thickness` | 2.4 | mm | Rear flange axial thickness | ≥4 line widths; must preserve air bound | Edge depth, skin, isolation |
| `tape_width` | 12.7 | mm | Intended foam tape width | ≥12.7 and ≤land width−2 allowances | Land width and tolerance |
| `tape_edge_allowance` | 2.5 | mm/side | Transverse placement tolerance | ≥2; tape+2 allowances ≤land width | Tape width, land width |
| `pair_gap` | 20 | mm | Raw model separation along bed Y | ≥2×planned brim+2; envelope must fit | Brim, depth, build Y |
| `planned_brim` | 8 | mm | Reserved slicer adhesion footprint | ≥0; pair clearance and fit must pass | Pair gap, build XY |
| `machine_margin` | 5 | mm/side | Additional reserved XY clearance | ≥0; envelope must fit | Build XY |
| `build_x` | 256 | mm | Rectangular usable bed width | >0 and ≥reserved width | Size, brim, margin |
| `build_y` | 256 | mm | Rectangular usable bed depth | >0 and ≥reserved depth | Count, depth, gap, brim, margin |
| `build_z` | 256 | mm | Usable print height | >0 and ≥2×apothem+Z clearance | Diameter, clearance |
| `z_clearance` | 5 | mm | Headroom reservation | ≥0; fit must pass | Build Z |
| `nominal_line_width` | 0.45 | mm | Minimum-wall geometry check | 0.25…0.8; walls and land ≥4×this value | Perimeter and land thickness |
| `minimum_face_isolation` | 1.6 | mm | Conservative clear-air rejection limit | ≥1.6 and ≤computed bound | Edge depth, skin, land, gradient |
| `minimum_skin_normal` | 2 | mm | Minimum actual facet thickness | ≥2 and ≤computed thickness | Skin axial, gradient |
| `minimum_cavity_radius` | 20 | mm | Minimum open rear hex circumradius | ≥20 and ≤derived opening radius | Diameter, land width |
| `maximum_overhang_step_ratio` | 1 | mm/mm | Geometric layer-advance limit | >0…1; roof and facet gradients must pass | Roof slope and facet gradient |
| `nominal_size_tolerance` | 1.524 | mm | Limit around 152.4 mm identity | 0…1.524 | Corner diameter |

`eps=0.02` is a fixed CSG overlap/cutting allowance, not a fit clearance or tolerance adjustment. Derived values (`r`, `a`, `depth`, normal factor, opening radii and envelopes) are not independent controls. The source enforces their relationships explicitly.

## Systematic design review and risk register

Review scope covers overall hex dimensions, facet topology, shell, cavity, perimeter, rear land and mounting plane; first contact, full-height section growth, unsupported closure, heat and movement risks; display/edge quality; pair practicality, cleanup and repeatability; mounting transfer; and assertions, bounds, topology and component count.

| Risk | Cause | Expected consequence | Current mitigation | Residual uncertainty | Validation required |
|---|---|---|---|---|---|
| Adhesion failure | Narrow base; surface preparation or temperature unsuitable | Base lifts or loses attachment | Continuous ~686 mm² nominal contact; 8 mm brim allowance | Actual bed, material and brim behavior unknown | Full first-layer inspection; video and base inspection during complete print |
| Structural instability | Tall upright part and layer-direction weakness | Lean, base fracture, tipping while brim stays attached | Continuous perimeter and integral land; no fragile tie points | No stiffness/load model or physical result | Full-height single trial; distinguish attached brim from bending tile |
| Upper-height oscillation | Cantilever dynamics, printer motion and nozzle contact | Ringing, waves or collisions near top | Hollow shell with depth; proposed conservative motion trial | Resonance, bed-slinger effects and pair coupling unknown | Video at lower/mid/upper zones; surface comparison by height |
| Roof under-support | Sloped internal closure or poor cooling | Sag, nozzle interference, local density line | 1:1 geometric roof advance; no upper flange bridge; 660 section samples | Geometric advance does not establish extrusion support | Inspect actual toolpaths and full roof region on first complete trial |
| Thermal telegraphing | Rear flange cutoff, perimeter/roof transitions, local solid mass | Horizontal or local impressions on display | No central bosses/ribs; ≥4.09 mm rear-land air bound; consistent face skin | Perimeter and roof remain joined; thermal/process response unmeasured | Raking-light face inspection; correlate lines to feature heights |
| Face texture and ripple | Layer texture, seams, ringing, filament variation | Hobby-like or inconsistent appearance | Support-free display; explicit planar facets | CAD says nothing about finish on chosen machine | Full-size printed samples, close and raking-light review, retained master |
| Bottom perimeter damage | Brim removal or elephant foot | Torn or swollen lower edge | Flat robust base; no breakaway structural features | No validated compensation or removal process | Measure bottom vs upper outline; timed brim cleanup without face sanding |
| Mount land flex or fracture | In-plane flange cantilever, anisotropy, installation pressure | Land bends, peels, cracks or marks front | 2.4 mm flange tied around continuous side/bottom perimeter | No force specification or tested material | Record installation force; test tape pressing, handling and pull/peel at representative loads |
| Adhesive or wall failure | Tape chemistry, wall coating, roughness, temperature and creep | Tile falls or tilts over time | 2,667 mm² designated tape area with placement tolerance | No adhesive product, substrate or service envelope supplied | Manufacturer-specific preparation and load basis; sustained and environmental tests on actual wall assembly |
| Pair regression | Added travel, heat history, cooling, machine vibration | Pair differs from accepted single | Independent tiles; 20 mm model gap; 4 mm nominal brim gap | No slicer or physical pair result | Compare individual tiles and cycle time against frozen single process |
| Cleanup exceeds target | Strong brim bond or poor lower-edge finish | >1 minute per pair, cosmetic repair required | No connected-pair separation; only slicer brim expected | Adhesion/cleanup balance not tested | Time bed removal and brim cleanup separately; fail if target or cosmetic requirements missed |
| Parametric regression | Extreme admitted settings or custom machine geometry | Valid-looking but unsuitable output | Named constraints, hard assertions, negative tests, mesh checks | Only defaults and four perturbations mesh-tested; rectangular envelope model | Re-run validator and slicer review for every source change; machine exclusion-zone check |
| Unacceptable commercial material performance | Unknown polymer, exposure, cleaning and project requirements | Service damage or unsuitable installation | No material or commercial release claim | Fire/smoke, cleaning, heat/UV, tampering and project acceptance unresolved | Select exact grade; obtain applicable project requirements and material evidence before installation |

The table records significant current risks; it does not present their mitigations as proven. A correct CAD model is insufficient to close any physical row.

## Trial plan and change control

1. **Freeze inputs.** Select the actual printer, usable volume and excluded zones, nozzle, exact material grade/color/lot, build surface, slicer and profile, tape product, substrate and service conditions. Set the bed parameters accordingly and re-render. Archive source and generated outputs with hashes.
2. **Slicer review before printing.** Import the upright single without auto-orientation. Drop to bed if the exporter introduces a sub-micron numerical Z offset. Verify units and dimensions, connected first layer, all contours, no unexpected islands, roof closure, exact line counts, seam location, speeds, cooling, brim envelope and toolhead clearances. Do not let automatic support contact the display face. If a slicer requests supports, investigate before accepting the result. Preserve the native project and generated machine file. No generic G-code is supplied because the machine is unknown.
3. **Establish one single-tile baseline.** A provisional starting trial may use a 0.4 mm nozzle, 0.45 mm line width, 0.16 mm layers, 0.20 mm first layer, at least four perimeter paths where geometry permits, 8 mm brim, all-at-once layer printing, display seams placed on a non-display perimeter, 30 mm/s external walls and 500 mm/s² external acceleration. Use the selected material's actual vendor temperature/cooling profile. These are test inputs, not a validated recipe; the configured machine may need a different safe motion limit. The CAD thickness must not be replaced by a slicer “shell thickness” value. Inspect thin bands and solid regions in the toolpath.
4. **Observe the entire print.** Record the first layer and lower (0–44 mm), middle (44–88 mm) and upper (88–132 mm) zones. A short coupon cannot prove full-height stability or final finish. Record completion, motion, nozzle interference and thermal effects distinctly.
5. **Measure and inspect after cooling.** Use the acceptance table below. Photograph both faces and all edges under the defined viewing conditions. Keep the specimen and its process record, including failures.
6. **Then test the independent pair.** Preserve the single's material and process settings so that the principal changed factor is layout/count. Record each tile separately, total cycle time, material use and cleanup. Do not represent a pair result as proving a material or motion change made simultaneously.
7. **Qualify installation and repeatability.** Use actual tape and a representative wall assembly, with service loads, cleaning and temperature defined for the site. A proposed screening minimum is three consecutive successful pair jobs on separate starts (six tiles), plus the initial single; this is an engineering screen, not a statistical guarantee. Broader lot/machine/operator/environment coverage must match the intended production scope. Reject a whole job's readiness status if any tile fails a required criterion.

Each further experiment needs an ID, exact revision, purpose, sole changed variable or explicit confounding set, measurable prediction, criterion and decision. Examples:

| Change | Purpose | Measurable expected effect | Acceptance / interpretation |
|---|---|---|---|
| Lower outer-wall acceleration only | Reduce upper motion | Less upper-zone ripple vs baseline | Must improve face without new dimensional/adhesion/cleanup/time failure; does not prove a geometry benefit |
| Increase edge depth only | Increase structural depth | Lower observed sway at unchanged motion | Must retain isolation/fit/depth, face and mounting acceptance; changing print time is recorded |
| Pair layout only | Increase job throughput | Two tiles matching accepted single quality | Both tiles meet all criteria; total cycle time and cleanup meet targets |
| Material grade only | Improve finish or service behavior | Better appearance or specified durability | Requalify adhesion, stability, dimensions, mounting and site suitability; do not attribute differences to CAD |

For every optimization, review face, adhesion, full-height stability, mounting, material use, dimensions, cleanup/separation and print duration. A simultaneous bundle may be useful for screening but cannot isolate any one cause.

## Proposed physical acceptance criteria

These make the next trial measurable. They are engineering targets awaiting physical evidence; the source does not enforce them. A stricter project or agreed physical master governs release.

| Test | Criterion / record |
|---|---|
| Completion | Full height, no collision, collapse, fracture or progressive lean. Record elapsed time and interventions; intervention-dependent success is not repeatable success. |
| First layer | Continuous intended contact and brim, no isolated islands, gaps, lifting or unintended above-bed starts. Record actual first-layer paths. |
| Stability by height | No tipping/base fracture/visible progressive lean in any zone. Record whether the bed bond stayed intact. Surface ripple cannot be excused because completion occurred. |
| Dimensions | Proposed cooled-part targets: 152.4±0.3 mm corner diameter at all three axes; 131.982±0.3 mm across flats; total depth 19±0.3 mm. Record all values and instrument uncertainty. Reject bowing even if the maximum dimension passes. |
| Facets and face | Retain the crisp asymmetric 13-plane appearance shown by the C02 CAD reference. At 300 mm viewing distance under 500–1000 lux diffuse light and a separate raking-light pass, no discrete horizontal density bands, bulges, depressions, rear impressions, scars, heat distortion or unacceptable ripple. Uniform FDM texture still requires approval against a retained physical master. No corrective display-face sanding. |
| Perimeter | No chips, torn edges, steps or perceptible mismatch when adjacent tiles are aligned. Proposed maximum local outline deviation 0.3 mm; inspect lower edge separately. |
| Mount plane | Proposed maximum rear-land gap 0.3 mm on a reference flat; no rocking attributable to warp, unsupported tape, cracked land or visible front distortion under recorded tape-application force. Thickness of actual tape is added to installed projection. |
| Tape placement | Five 12.7 mm strips fit the designated lands without unsupported overhang; document actual locations, product and area. No assumed strength from area alone. |
| Cleanup / separation | No pair connections to separate. Time bed release, brim removal and all cleanup separately. Target <60 s total routine separation/cleanup per pair; fail for tearing, stress marks, repairs, aggressive twisting or face prying. |
| Print time | Record actual slicer estimate and elapsed job time. Target approximately ≤9 h per pair; evaluate any exceedance explicitly against the product brief. No time claim made here. |
| Handling | No cracks, visible permanent set or face damage during documented bed removal, packing, transport simulation, tape pressing and alignment. Define transport procedure and forces before testing. |
| Installed bond and service | Define maximum installation/handling loads, substrate, material, temperature/humidity and required service life first. Use tape manufacturer's product-specific design basis and test the full wall/paint/tape/tile stack. No universal test load, dwell or safe life is asserted. |
| Repeatability | At least the stated screening series passes without cosmetic repair. Extend tests across intended lots, operators, machines and service conditions before claiming the applicable production scope. |
| Commercial installation | Exact material and completed assembly satisfy the site's applicable project requirements. Geometry and a successful print do not establish this. |

## Failure classification

| Class | Discriminating observation | Record separately from |
|---|---|---|
| Adhesion failure | Base or brim loses bond to bed | An attached base with a bending tile |
| Structural instability | Bed remains attached but tile bends, fractures, leans or tips | Poor bed adhesion |
| High-level oscillation | Tile stays upright but increasing-height movement causes ripple or risk | A generic “print failed” label |
| Geometry failure | Dimensional, clearance, topology or layer-geometry defect | Material/process defects |
| Surface-quality failure | Print completes but display/perimeter fails visual criteria | Completion success |
| Separation failure | Removal/cleanup damages tile or exceeds criterion | Mounting or print-completion success |
| Mounting failure | Land/adhesive/wall interface fails, distorts or is unusable | Adequate CAD tape area |

More than one class may apply. Record the primary observed event and secondary consequences; do not infer the initiating cause without evidence.

## Requirement disposition

| Brief requirements | Current disposition |
|---|---|
| 1, 3–6, 19–20: refined face, facets, edges, depth, consistency | Reference-inspired asymmetric CAD and 19 mm depth provided; commercial appearance and tile-to-tile print consistency untested. |
| 2: size | Default regular hex matches 152.4 mm corner diameter; measured STL within serialization tolerance. |
| 7: hollow rear | Open cavity; one connected hollow-shell tile; 57.03 cm³ CAD volume. No solid-block conversion. |
| 8, 18: mounting | Flat CAD U-land, checked tape fit and structural continuity; printed flatness, strength and durability untested. |
| 9: isolation | Rear-land air bound and face thickness computed and checked; shell-joint interpretation and thermal effect explicitly limited above. |
| 10–12: orientation, bed contact, stability | Defined upright orientation; broad continuous geometric contact; 660 connected sections. Dynamic stability and actual adhesion untested. |
| 13: multiple tiles | Independent two-tile output fits assumed volume. No evidence yet that pair equals single quality. |
| 14–17: temporary features, separation, cleanup, handling | No CAD temporary features or pair ties. Slicer brim cleanup and handling remain physical gates. |
| 21–26: parameters, guards, geometry, modes, fit, clearances | Implemented and checked for defaults and stated test cases; no claim of exhaustive parameter-space certification. No production-ready mode exposed. |
| 27–31: classification, acceptance, repeatability, change control, record | Procedures and blank record supplied; no physical trials invented. Repeatability not demonstrated. |
| 32: source quality | Standalone source; named groups, explicit geometry, no imports, omitted modules, placeholder geometry or dead production alternatives. |
| 33–35: regression review, freedom, systematic risk review | Candidate chosen by stated reasoning; risk register and experiment controls supplied; optimality unproved. |
| 36: deliverables | Source, rationale, parameter table, numeric validation and honest readiness assessment supplied. Slicer project and physical evidence await a real machine/process. |
| 37–38: final acceptance and engineering standard | Not yet met as a whole. Product remains an unreleased geometry candidate. |

## Sources and evidence

The brief is the engineering authority; the supplied image is the appearance reference. Exact inferred depths are not treated as image facts. Numerical statements are derived from `tile.scad` and the exact exported meshes, with machine-readable lineage in `evidence/validation.json`. No physical result, simulated load result, slicer estimate or certified service rating is present.

General process reasoning was checked against primary documentation:

- [OpenSCAD: polyhedron primitives](https://files.openscad.org/documentation/manual/Primitive_Solids.html) — explicit faces and manifold requirements.
- [OpenSCAD: assert](https://files.openscad.org/documentation/manual/The_OpenSCAD_Language.html) — errors on invalid parameter relationships.
- [OpenSCAD: command line export](https://files.openscad.org/documentation/manual/Using_OpenSCAD_in_a_command_line_environment.html) — parameter overrides and file output.
- [Prusa: Modeling with 3D printing in mind](https://help.prusa3d.com/article/modeling-with-3d-printing-in-mind_164135) — orientation/support finish tradeoffs and machine-dependent overhang behavior. This is general guidance, not certification of this roof or tile.

## Release assessment

| Classification | Status | Basis |
|---|---|---|
| GEOMETRICALLY VALIDATED | **Yes, scoped** | Default CAD render, component topology, bounds, explicit facet areas, rear-plane coverage, rear-land isolation bound, section sampling, assertions and specified perturbations. Shell-joint interpretation remains stated, not silently resolved. |
| SLICER VALIDATED | **No** | No selected printer/profile or reviewed native slicer project/toolpaths. |
| PHYSICALLY TESTED | **No** | No physical specimen or manufacturing run. |
| REPEATABILITY VALIDATED | **No** | No repeated complete prints or installation tests. |
| PRODUCTION READY | **No** | Appearance, dynamics, cleanup, time, material, adhesive and service evidence are still absent. |

The default must stay a trial output until those gates close. Successful rendering is evidence of geometry processing, not evidence that the installed product meets the complete brief.
