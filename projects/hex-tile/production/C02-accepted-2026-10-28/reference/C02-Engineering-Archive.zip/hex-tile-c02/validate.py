#!/usr/bin/env python3
"""Rebuild exact CAD outputs and inspect them; no physical/slicer claims.
Requires OpenSCAD >=2021.01; Python numpy, trimesh, shapely, rtree, networkx, matplotlib.
Run from any directory: python3 /path/to/validate.py
"""
from pathlib import Path
import hashlib
import json
import math
import platform
import importlib.metadata
import subprocess
import sys
import time

import numpy as np
import trimesh
import shapely
from shapely.geometry import Polygon
from shapely.ops import unary_union

ROOT = Path(__file__).resolve().parent
ART = ROOT / 'artifacts'
EVID = ROOT / 'evidence'
ART.mkdir(exist_ok=True)
EVID.mkdir(exist_ok=True)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def render(name, overrides):
    target = ART / f'{name}.stl'
    target.unlink(missing_ok=True)  # Never accept a stale artifact after a failed run.
    cmd = ['openscad', '--hardwarnings', '--export-format', 'asciistl', '-o', str(target)]
    for key, value in overrides.items():
        cmd += ['-D', f'{key}={json.dumps(value)}']
    cmd += [str(ROOT / 'tile.scad')]
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=90)
    log = result.stdout + result.stderr
    (EVID / f'{name}.log').write_text(log)
    ok = result.returncode == 0 and target.exists() and 'ERROR:' not in log
    return ok, target, log


def mesh_check(path, expected_components):
    mesh = trimesh.load_mesh(path, process=True)
    components = mesh.split(only_watertight=False)
    triangles = mesh.triangles
    duplicates = len(mesh.faces) - len(np.unique(np.sort(mesh.faces, axis=1), axis=0))
    result = {
        'sha256': digest(path), 'vertices': len(mesh.vertices), 'triangles': len(mesh.faces),
        'connected_components': len(components), 'watertight': bool(mesh.is_watertight),
        'winding_consistent': bool(mesh.is_winding_consistent),
        'positive_volume_each_component': all(m.volume > 0 for m in components),
        'duplicate_triangles': int(duplicates),
        'degenerate_triangles': int(np.sum(mesh.area_faces < 1e-8)),
        'bounds_mm': mesh.bounds.tolist(), 'dimensions_mm': mesh.extents.tolist(),
        'volume_mm3': float(mesh.volume),
        'minimum_z_mm': float(triangles[:, :, 2].min()),
    }
    assert result['connected_components'] == expected_components, result
    assert result['watertight'] and result['winding_consistent'], result
    assert result['positive_volume_each_component'] and not duplicates, result
    assert result['degenerate_triangles'] == 0, result
    return mesh, result


def section_polygon(mesh, z):
    section = mesh.section(plane_origin=[0, 0, z], plane_normal=[0, 0, 1])
    if section is None:
        return Polygon()
    # Symmetric difference retains holes without depending on loop winding.
    result = Polygon()
    for curve in section.discrete:
        poly = Polygon(curve[:, :2])
        assert poly.is_valid
        result = result.symmetric_difference(poly)
    assert result.is_valid
    return result


def layer_geometry_check(mesh):
    height = float(mesh.bounds[1, 2])
    step = .2
    levels = np.arange(.1, height, step)
    previous = None
    max_excess = 0.
    max_parts = 0
    first = None
    for z in levels:
        poly = section_polygon(mesh, z)
        assert not poly.is_empty
        parts = len(poly.geoms) if poly.geom_type == 'MultiPolygon' else 1
        max_parts = max(max_parts, parts)
        if first is None:
            first = {'height_mm': float(z), 'area_mm2': float(poly.area),
                     'bounds_xy_mm': list(poly.bounds), 'connected_regions': parts}
        if previous is not None:
            # 1:1 geometric advance + 0.002 mm for ASCII mesh / clipping precision.
            excess = poly.difference(previous.buffer(step + .002))
            max_excess = max(max_excess, excess.area)
        previous = poly
    assert max_excess < .01, max_excess
    assert max_parts == 1, max_parts
    return {'sample_step_mm': step, 'section_count': len(levels),
            'maximum_cross_section_components': max_parts,
            'maximum_area_outside_previous_layer_advance_mm2': max_excess,
            'advance_allowance_mm': step + .002, 'first_sample': first,
            'scope': 'Geometric 0.2 mm section sampling; not slicer toolpaths or dynamics.'}


def expected_face_pattern():
    r, edge, rise = 76.2, 9., 10.
    xy = np.array([[math.cos(math.radians(60*i)),math.sin(math.radians(60*i))]
                    for i in range(6)] +
                  [[-.36,.18],[.02,.46],[.16,.05],[-.16,-.38],[.34,-.28]])*r
    n = np.array([math.cos(math.pi/6),-.5])
    e = (r*math.cos(math.pi/6)-xy[10].dot(n))/(r*math.cos(math.pi/6)-xy[8].dot(n))
    heights = edge+rise*np.array([0,0,0,0,0,0,.8,.55,1,.6,e])
    tris = np.array([[1,8,0],[4,9,3],[5,9,4],[1,7,8],[2,7,1],
        [9,10,8],[5,10,9],[8,10,0],[10,5,0],[6,2,3],[6,7,2],
        [9,6,3],[6,9,8],[7,6,8]])
    xyz = np.c_[xy,heights]
    gradients = np.array([np.linalg.solve(np.c_[xy[t],np.ones(3)],heights[t])[:2] for t in tris])
    return xyz,tris,gradients


def display_and_mount_checks(mesh):
    r, edge, rise, skin, land = 76.2, 9., 10., 2.4, 2.4
    a = r*math.cos(math.pi/6)
    vertices = mesh.triangles
    xyz,tris,gradients = expected_face_pattern()
    flat = vertices[:,:,:2].reshape(-1,2)
    expected_z = np.full(len(flat),np.nan)
    for t in tris:
        corners = xyz[t,:2]
        bary = np.linalg.solve(np.vstack([corners.T,np.ones(3)]),
                                np.vstack([flat.T,np.ones(len(flat))])).T
        inside = np.all(bary>=-2e-5,axis=1)
        expected_z[inside] = bary[inside]@xyz[t,2]
    assert np.all(np.isfinite(expected_z))
    expected_z = expected_z.reshape(vertices.shape[:2])
    outer = np.all(np.abs(vertices[:,:,2]-expected_z)<.002,axis=1)&(mesh.face_normals[:,2]>.1)
    inner = np.all(np.abs(vertices[:,:,2]-(expected_z-skin))<.002,axis=1)&(mesh.face_normals[:,2]<-.1)
    assert outer.sum() > 0 and inner.sum() > 0
    facet_normals = []
    for n in mesh.face_normals[outer]:
        if all(np.linalg.norm(n-p)>.001 for p in facet_normals): facet_normals.append(n)
    assert len(facet_normals) == 13, facet_normals
    patches = [Polygon(xyz[t,:2]) for t in tris]
    union = unary_union(patches)
    outline = Polygon(xyz[:6,:2])
    assert abs(sum(p.area for p in patches)-union.area)<1e-6
    assert outline.symmetric_difference(union).area<1e-6
    maximum_gradient = float(np.linalg.norm(gradients,axis=1).max())
    normal_factor = math.sqrt(1+maximum_gradient**2)
    rear_mask = np.all(np.abs(vertices[:, :, 2]) < .00001, axis=1)
    rear = unary_union([Polygon(t[:, :2]) for t in vertices[rear_mask]])
    tape_polys = []
    strips = []
    pts = np.array([[r*math.cos(math.radians(i*60)), r*math.sin(math.radians(i*60))]
                    for i in range(6)])
    for i, length in [(0,30), (2,30), (3,50), (4,50), (5,50)]:
        p, q = pts[i], pts[(i+1)%6]
        tangent = (q-p)/np.linalg.norm(q-p)
        inward = -(p+q)/np.linalg.norm(p+q)
        center = (p+q)/2 + inward*17.7/2
        def rectangle(c):
            return Polygon([c+s*tangent*length/2+t*inward*12.7/2
                            for s,t in [(-1,-1),(1,-1),(1,1),(-1,1)]])
        shape = rectangle(center)
        for shift in [-2.5, 0, 2.5]:
            assert rectangle(center+shift*inward).difference(rear.buffer(.002)).area < .01
        tape_polys.append(shape)
        strips.append({'hex_edge_index': i, 'length_mm': length, 'width_mm': 12.7,
                       'center_xy_mm': center.tolist(), 'tangent_xy': tangent.tolist()})
    tape_area = unary_union(tape_polys).area
    assert abs(tape_area-2667) < .01
    # Mesh-based nearest-point sampling supplements the analytic bound.
    face_inner = mesh.submesh([np.flatnonzero(inner)], append=True)
    sample = []
    for poly in tape_polys:
        coords = np.asarray(poly.exterior.coords)[:-1]
        for u in np.linspace(0,1,5):
            for v in np.linspace(0,1,5):
                xy = coords[0]+u*(coords[1]-coords[0])+v*(coords[3]-coords[0])
                sample.append([*xy,land])
    _, distances, _ = trimesh.proximity.closest_point(face_inner, np.array(sample))
    conservative_bound = (edge-skin-land)/normal_factor
    assert distances.min() >= conservative_bound-.002
    front_area_expected = float(trimesh.triangles.area(xyz[tris]).sum())
    assert abs(mesh.area_faces[outer].sum()-front_area_expected) < .1
    return {
        'explicit_display_facets': len(facet_normals),
        'explicit_triangle_patches': len(tris),
        'interior_junction_count':5,
        'maximum_face_gradient': maximum_gradient,
        'reference_image_sha256':digest(ROOT/'reference-face.png'),
        'reference_interpretation':'XY junction pattern follows image approximately; Z heights are chosen design values.',
        'pattern_vertices_xyz_mm':xyz.tolist(),
        'face_triangle_xy_union_matches_hex':True,
        'face_triangle_xy_overlap_area_mm2':float(sum(p.area for p in patches)-union.area),
        'display_area_mesh_mm2': float(mesh.area_faces[outer].sum()),
        'display_area_analytic_mm2': front_area_expected,
        'skin_normal_analytic_mm': skin/normal_factor,
        'rear_plane_max_abs_z_mm': float(np.abs(vertices[rear_mask, :, 2]).max()),
        'total_rear_coplanar_area_mm2': float(rear.area),
        'verified_tape_rectangles': strips,
        'nonoverlapping_nominal_tape_area_mm2': float(tape_area),
        'transverse_tape_placement_test_mm': [-2.5, 0, 2.5],
        'face_skin_clear_air_lower_bound_analytic_mm': conservative_bound,
        'sampled_tape_land_to_inner_face_min_mm': float(distances.min()),
        'isolation_sample_points': len(sample),
        'isolation_scope': 'Rear tape land to face skin; intrinsic perimeter/roof shell connects intentionally.',
        'rear_surface_definition': 'CAD plane only; printed flatness and bond strength untested.'
    }, tape_polys


def illustrations(mesh, tape_polys):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    def raster(camera, include_tape):
        # Orthographic z-buffer avoids transparent-looking rear geometry and
        # painter-sort artifacts on a hollow object. No decorative triangulation.
        forward = np.array(camera,dtype=float); forward /= np.linalg.norm(forward)
        right = np.cross([0,1,0],forward); right /= np.linalg.norm(right)
        up = np.cross(forward,right)
        matrix = np.array([right,up,forward]).T
        tris = list(mesh.triangles)
        light = np.array([-.45,.65,1.0 if camera[2]>0 else -1.0])
        light /= np.linalg.norm(light)
        shades = .42+.50*np.maximum(0,np.round(mesh.face_normals,4).dot(light))
        colors = [np.array([.82,.88,.94])*s for s in shades]
        if include_tape:
            for poly in tape_polys:
                p = np.c_[np.array(poly.exterior.coords)[:-1],np.full(4,-.02)]
                tris.extend([p[[0,1,2]],p[[0,2,3]]])
                colors.extend([np.array([.86,.57,.19])]*2)
        size = 900
        out = np.full((size,size,3),[.96,.956,.941])
        depths = np.full((size,size),-np.inf)
        for tri, color in zip(tris,colors):
            p = (np.asarray(tri)-[0,0,8])@matrix
            p[:,:2] = p[:,:2]*4.65 + size/2
            lo = np.maximum(0,np.floor(p[:,:2].min(axis=0)).astype(int))
            hi = np.minimum(size-1,np.ceil(p[:,:2].max(axis=0)).astype(int))
            if np.any(hi<lo):
                continue
            x,y = np.meshgrid(np.arange(lo[0],hi[0]+1),np.arange(lo[1],hi[1]+1))
            den = (p[1,1]-p[2,1])*(p[0,0]-p[2,0])+(p[2,0]-p[1,0])*(p[0,1]-p[2,1])
            if abs(den)<1e-9:
                continue
            u=((p[1,1]-p[2,1])*(x-p[2,0])+(p[2,0]-p[1,0])*(y-p[2,1]))/den
            v=((p[2,1]-p[0,1])*(x-p[2,0])+(p[0,0]-p[2,0])*(y-p[2,1]))/den
            w=1-u-v
            z=u*p[0,2]+v*p[1,2]+w*p[2,2]
            old=depths[lo[1]:hi[1]+1,lo[0]:hi[0]+1]
            valid=(u>=-1e-8)&(v>=-1e-8)&(w>=-1e-8)&(z>old)
            old[valid]=z[valid]
            out[lo[1]:hi[1]+1,lo[0]:hi[0]+1][valid]=color
        return np.flipud(out)
    fig,axes = plt.subplots(1,2,figsize=(14,7.5),facecolor='#f5f4f0')
    for ax,camera,tape,title in zip(axes,[[.2,-.3,1],[.2,-.3,-1]],[False,True],
         ['Display face — asymmetric reference-inspired facets','Rear — U-shaped tape land and open cavity']):
        ax.imshow(raster(camera,tape)); ax.set_axis_off(); ax.set_title(title,fontsize=12,pad=5)
    fig.suptitle('C02 | 152.4 mm faceted hex tile | GEOMETRY CANDIDATE',fontsize=17,y=.96)
    fig.text(.5,.05,'Engineering mesh views; not photographs or evidence of printed finish. Gold = nominal tape strips.',ha='center',fontsize=10)
    fig.savefig(ROOT/'design-preview.png',dpi=150,bbox_inches='tight')
    plt.close(fig)
    fig,ax = plt.subplots(figsize=(7,7),facecolor='#f5f4f0')
    ax.imshow(raster([0,0,1],False)); ax.set_axis_off()
    ax.set_title('C02 | asymmetric faceted face',fontsize=16,pad=8)
    fig.text(.5,.05,'Actual CAD geometry · shaded single material · unprinted candidate',ha='center',fontsize=9)
    fig.savefig(ROOT/'face-preview.png',dpi=160,bbox_inches='tight')
    plt.close(fig)


def main():
    started = time.time()
    report = {'candidate': 'C02', 'source_sha256': digest(ROOT/'tile.scad'),
              'validator_sha256': digest(Path(__file__)),
              'tools': {'openscad': subprocess.check_output(['openscad','--version'],stderr=subprocess.STDOUT,text=True).strip(),
                        'python':platform.python_version(), 'numpy':np.__version__,
                        'trimesh':trimesh.__version__, 'shapely':shapely.__version__,
                        'networkx':importlib.metadata.version('networkx'),
                        'rtree':importlib.metadata.version('rtree'),
                        'matplotlib':importlib.metadata.version('matplotlib')},
              'outputs':{}, 'negative_guards':{}, 'valid_perturbations':{}}
    meshes = {}
    for mode, expected in [('inspect',1),('trial_single',1),('trial_pair',2),('section',1)]:
        ok, path, log = render('tile-'+mode, {'mode':mode})
        assert ok and 'Simple:        yes' in log, log
        meshes[mode], report['outputs'][mode] = mesh_check(path,expected)
    local = meshes['inspect']
    checks, tapes = display_and_mount_checks(local)
    report['display_and_mount'] = checks
    report['sampled_layer_geometry'] = layer_geometry_check(meshes['trial_single'])
    a = 76.2*math.cos(math.pi/6)
    assert np.allclose(local.extents,[152.4,2*a,19],atol=.002)
    report['build_fit'] = {'assumed_volume_mm':[256,256,256],
        'single_reserved_envelope_mm':[178.4,45,2*a+5],
        'pair_reserved_envelope_mm':[178.4,84,2*a+5],
        'brim_allowance_mm':8,'machine_margin_each_side_mm':5,'top_clearance_mm':5,
        'raw_pair_gap_mm':20,'nominal_gap_between_pair_brims_mm':4}
    single = meshes['trial_single']
    comparison = []
    for part in meshes['trial_pair'].split():
        aligned = part.copy()
        aligned.apply_translation(single.bounds.mean(axis=0)-part.bounds.mean(axis=0))
        probes = np.vstack([aligned.vertices, aligned.triangles_center])
        _, distances, _ = trimesh.proximity.closest_point(single,probes)
        assert distances.max() < .002
        comparison.append(float(distances.max()))
    report['pair_equivalence'] = {
        'method':'Align bounding-box centers; nearest-surface distance for all vertices and triangle centers.',
        'maximum_sampled_deviation_each_tile_mm':comparison,
        'scope':'Geometric output comparison only; not equal printed quality.'}
    cases = {
        'unknown_mode':{'mode':'production'}, 'wrong_nominal_size':{'corner_diameter':160},
        'negative_depth':{'edge_depth':-1}, 'excessive_depth':{'facet_rise':20},
        'thin_skin':{'skin_axial':1}, 'thin_perimeter':{'perimeter_wall':1},
        'thin_land':{'land_thickness':1}, 'no_land_overlap':{'perimeter_wall':18},
        'face_isolation':{'edge_depth':6}, 'cannot_lower_isolation_limit':{'minimum_face_isolation':.5},
        'narrow_tape_land':{'land_width':15}, 'no_tape_tolerance':{'tape_edge_allowance':1},
        'closed_cavity':{'land_width':60}, 'zero_roof_slope':{'roof_slope':0},
        'steep_roof':{'roof_slope':2}, 'overlapping_brims':{'pair_gap':10},
        'negative_brim':{'planned_brim':-1}, 'negative_margin':{'machine_margin':-1},
        'bed_x':{'build_x':170}, 'bed_y_pair':{'mode':'trial_pair','build_y':80},
        'bed_z':{'build_z':130}, 'unsupported_line_width':{'nominal_line_width':1},
        'short_face_profile':{'facet_profile':[.8,.55,1]},
        'zero_face_profile':{'facet_profile':[0,.55,1,.6]},
        'unnormalized_face_profile':{'facet_profile':[.8,.55,.9,.6]},
        'negative_face_profile':{'facet_profile':[-.8,.55,1,.6]},
    }
    for name, override in cases.items():
        ok,path,log = render('reject-'+name, override)
        assert not ok and 'Assertion' in log, (name,log)
        report['negative_guards'][name] = {'rejected':True,'overrides':override}
        path.unlink(missing_ok=True)
    for name, override in {
        'deeper_edge':{'mode':'inspect','edge_depth':10},
        'lower_relief':{'mode':'inspect','facet_rise':8},
        'wider_land':{'mode':'inspect','land_width':19},
        'smaller_nozzle_line':{'mode':'inspect','nominal_line_width':.4},
    }.items():
        ok,path,log = render('variation-'+name,override)
        assert ok and 'Simple:        yes' in log,log
        _, result = mesh_check(path,1)
        report['valid_perturbations'][name] = {'overrides':override,'mesh':result}
    illustrations(local,tapes)
    report['readiness'] = {'GEOMETRICALLY VALIDATED':'PASS, stated CAD checks only',
        'SLICER VALIDATED':'NOT PERFORMED','PHYSICALLY TESTED':'NOT PERFORMED',
        'REPEATABILITY VALIDATED':'NOT PERFORMED','PRODUCTION READY':'NO'}
    report['elapsed_seconds'] = round(time.time()-started,2)
    (EVID/'validation.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))


if __name__ == '__main__':
    try:
        main()
    except Exception:
        (EVID/'validation.json').unlink(missing_ok=True)
        raise
